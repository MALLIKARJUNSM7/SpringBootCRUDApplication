package com.mallikarjun.example.repository;

import org.springframework.data.repository.CrudRepository;

import com.mallikarjun.example.model.Subject;

public interface SubjectRepository extends CrudRepository<Subject,String> {
	

}
