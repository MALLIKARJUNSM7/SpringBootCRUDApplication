package com.mallikarjun.example.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Subject")
public class Subject {
	
	@Id
	private String id;
	private String subjectname;
	private int price;
	
    public Subject() {
		
	}
	
	public Subject(String id, String subjectname, int price) {
		super();
		this.id = id;
		this.subjectname = subjectname;
		this.price = price;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSubjectname() {
		return subjectname;
	}

	public void setSubjectname(String subjectname) {
		this.subjectname = subjectname;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	
	

	
	
	
	
}
