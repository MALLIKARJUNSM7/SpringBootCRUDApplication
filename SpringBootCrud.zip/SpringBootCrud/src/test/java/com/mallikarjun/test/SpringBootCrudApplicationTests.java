package com.mallikarjun.test;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SpringBootCrudApplicationTests {

	@Test
	public void contextLoads() {
		
	}

}
